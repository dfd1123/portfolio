<template>
  <div class="popup_content_wrap">
    <div class="video-popup_con_image">contents background</div>
    <div class="video-popup_con_iframe">contents video</div>
  </div>
</template>

<script>
export default {
  name: "video-popup"
};
</script>

<style scoped>
</style>