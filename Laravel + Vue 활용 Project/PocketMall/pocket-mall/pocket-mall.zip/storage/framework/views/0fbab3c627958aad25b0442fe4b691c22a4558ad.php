<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <h1 class="mt-4">상품 리스트</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.settings')); ?>">상품</a></li>
        <li class="breadcrumb-item active">상품 관리</li>
    </ol>
    <div class="card mb-4">
        <div class="card-body">
          <div class="mb-10"  style="overflow:hidden;">
              <a href="<?php echo e(route('admin.items.create')); ?>" class="btn btn-success btn-sm float-right">상품 추가</a>
          </div>
          <div class="row">
            <div class="col-4">
              <div class="list-group" id="list-tab" role="tablist">
                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($loop->first): ?>
                    <a class="list-group-item list-group-item-action active" id="list-<?php echo e($category->ca_id); ?>-list" data-toggle="list" href="#list-<?php echo e($category->ca_id); ?>" role="tab" aria-controls="<?php echo e($category->ca_id); ?>"><?php echo e($category->ca_name); ?></a>
                  <?php else: ?>
                    <a class="list-group-item list-group-item-action" id="list-<?php echo e($category->ca_id); ?>-list" data-toggle="list" href="#list-<?php echo e($category->ca_id); ?>" role="tab" aria-controls="<?php echo e($category->ca_id); ?>"><?php echo e($category->ca_name); ?></a>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <div class="col-8">
              <div class="tab-content" id="nav-tabContent">
                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade show <?php echo e($loop->first?'active':''); ?>" id="list-<?php echo e($category->ca_id); ?>" role="tabpanel" aria-labelledby="list-<?php echo e($category->ca_id); ?>-list">
                      <div id="list-example" class="list-group">  
                        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <?php if($category->ca_id === $item->ca_id): ?>
                            <a class="list-group-item list-group-item-action" href="<?php echo e(route('admin.items.edit', $item->item_id)); ?>"><?php echo e($item->title); ?></a>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            상품 없음
                        <?php endif; ?>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<script>
  $('.delete_category').on('submit', function(){
    if(confirm('정말 삭제하시겠습니까?')){
      return true;
    }else{
      return false;
    }
  });
</script>

<?php $__env->startSection('script'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\my\project\repository\pocket-mall\resources\views/admin/items/list.blade.php ENDPATH**/ ?>