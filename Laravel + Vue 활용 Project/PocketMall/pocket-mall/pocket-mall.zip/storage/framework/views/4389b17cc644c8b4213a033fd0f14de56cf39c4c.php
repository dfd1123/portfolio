<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <h1 class="mt-4">상품 옵션 리스트</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.item_options')); ?>">상품</a></li>
        <li class="breadcrumb-item active">상품 옵션 관리</li>
    </ol>
    <div class="card mb-4">
        <div class="card-body">
        <select id="category_select" class="custom-select" style="margin-bottom:30px;" value="<?php echo e($ca_id); ?>">
          <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->ca_id); ?>" <?php echo e($category->ca_id == $ca_id?'selected':''); ?>><?php echo e($category->ca_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
          <div class="row">
            <div class="col-4">
              <div class="list-group" id="list-tab" role="tablist">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($loop->first): ?>
                    <a class="list-group-item list-group-item-action active" id="list-<?php echo e($item->item_id); ?>-list" data-toggle="list" href="#list-<?php echo e($item->item_id); ?>" role="tab" aria-controls="<?php echo e($item->item_id); ?>"><?php echo e($item->title); ?></a>
                  <?php else: ?>
                    <a class="list-group-item list-group-item-action" id="list-<?php echo e($item->item_id); ?>-list" data-toggle="list" href="#list-<?php echo e($item->item_id); ?>" role="tab" aria-controls="<?php echo e($item->item_id); ?>"><?php echo e($item->title); ?></a>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <div class="col-8">
              <div class="tab-content" id="nav-tabContent">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade show <?php echo e($loop->first?'active':''); ?>" id="list-<?php echo e($item->item_id); ?>" role="tabpanel" aria-labelledby="list-<?php echo e($item->item_id); ?>-list">
                      <div id="list-example" class="list-group">  
                        <?php $__currentLoopData = $item_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($item->item_id === $option->item_id): ?>
                            <a class="list-group-item list-group-item-action" href="<?php echo e(route('admin.item_options.edit', $option->op_id)); ?>"><?php echo e($option->op_type); ?>(<?php echo e($option->op_concept); ?>)/<?php echo e($option->op_simple_intro); ?>/추가비용:+<?php echo e(number_format($option->op_sale_price, 0)); ?>원</a>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn btn-success btn-lg btn-block" href="<?php echo e(route('admin.item_options.create')); ?>?item_id=<?php echo e($item->item_id); ?>">+ 추가</a>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\my\project\repository\pocket-mall\resources\views/admin/item_options/list.blade.php ENDPATH**/ ?>