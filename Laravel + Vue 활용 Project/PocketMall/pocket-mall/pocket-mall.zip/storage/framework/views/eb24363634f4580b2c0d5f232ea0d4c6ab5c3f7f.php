<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <h1 class="mt-4">견적서 요청 리스트</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.item_options')); ?>">견적서 요청</a></li>
        <li class="breadcrumb-item active">견적서 요청 관리</li>
    </ol>
    <div class="card mb-4">
        <div class="card-body">
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">no</th>
              <th scope="col">이름</th>
              <th scope="col">전화번호</th>
              <th scope="col">이메일</th>
              <th scope="col">요청 날짜</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($invoice->rq_id); ?></th>
              <td><a href="/check-invoice?rq_id=<?php echo e($invoice->rq_id); ?>" target="_blank"><?php echo e($invoice->req_name); ?></a></td>
              <td><a href="/check-invoice?rq_id=<?php echo e($invoice->rq_id); ?>" target="_blank"><?php echo e($invoice->req_tel); ?></a></td>
              <td><a href="/check-invoice?rq_id=<?php echo e($invoice->rq_id); ?>" target="_blank"><?php echo e($invoice->req_email); ?></a></td>
              <td><a href="/check-invoice?rq_id=<?php echo e($invoice->rq_id); ?>" target="_blank"><?php echo e($invoice->created_at); ?></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
          <?php if($invoices): ?>
            <div style="text-align:center; margin: 30px 0;">
              <?php echo $invoices->render(); ?>

            </div>
          <?php endif; ?>
        
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\my\project\repository\pocket-mall\resources\views/admin/invoices/list.blade.php ENDPATH**/ ?>