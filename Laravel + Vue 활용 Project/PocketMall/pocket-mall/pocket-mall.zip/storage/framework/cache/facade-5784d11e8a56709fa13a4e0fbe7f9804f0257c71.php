<?php

namespace Facades\App\Classes;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Classes\File_store
 */
class File_store extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'App\Classes\File_store';
    }
}
