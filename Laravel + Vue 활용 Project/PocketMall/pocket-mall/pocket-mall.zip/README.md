# pocket-mall

1. composer install

2. npm install

### 실행순서

1. 가상서버 틀기

-xampp start
-php artisan --local localhost --port 8080 (--local 뒤에는 원하는 가상서버명, --port 뒤에는 빈 포트번호)

2. npm run watch-poll 로 app.js와 css 등 업데이트
